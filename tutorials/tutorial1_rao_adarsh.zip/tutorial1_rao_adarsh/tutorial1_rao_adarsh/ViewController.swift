//
//  ViewController.swift
//  tutorial1_rao_adarsh
//
//  Created by Adarsh Rao on 9/18/20.
//  Copyright © 2020 Adarsh Rao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewWillLoad()")
        // Do any additional setup after loading the view.
    
        func viewWillAppear() {
            super.viewWillAppear(true)
            print("viewWillAppear()")
            // Do any additional setup after loading the view.
        }
        
        func viewDidAppear() {
            super.viewDidAppear(true)
            print("viewDidAppear()")
            // Do any additional setup after loading the view.
        }
        
        func viewWillDisappear() {
            super.viewWillDisappear(true)
            print("viewWilDisappear()")
            // Do any additional setup after loading the view.
        }
        
        func viewDidDisappear() {
            super.viewDidDisappear(true)
            print("viewDidDisappear()")
            // Do any additional setup after loading the view.
        }

    }
}

